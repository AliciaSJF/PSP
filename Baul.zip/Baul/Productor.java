package Baul;

import java.security.SecureRandom;
import java.time.Instant;
import java.util.ArrayList;

public class Productor implements Runnable {
    private ArrayList<Character> caracteres;
    private Baul baul;
    private String nombre;
    private int numCaracteres;

    public Productor(Baul baul, String nombre, int numCaracteres) {
        this.numCaracteres = numCaracteres;
        caracteres  = new ArrayList<>(numCaracteres);
        for (int i = 0; i < numCaracteres/3; i++) {
            caracteres.add('A');
            caracteres.add('B');
            caracteres.add('C');
        }
        this.baul = baul;
        this.nombre = nombre;
    }

    public int getLlenadas() {
        return numCaracteres-caracteres.size();
    }

    public String getNombre() {
        return nombre;
    }

    @Override
    public void run() {
        SecureRandom random = new SecureRandom();
        for (int i = caracteres.size(); i > 0; i--) {
            int indice = random.nextInt(caracteres.size());

            synchronized (baul) {
                while (!baul.estaVacio()) {
                    try {
                        baul.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.printf("%s llena el baúl con el caracter %s en el instante: %s\n", nombre, caracteres.get(indice), Instant.now());
                baul.setCaracter(caracteres.remove(indice));
                System.out.println(baul);
                baul.notifyAll();
                System.out.printf("%s espera a que se vacíe el baúl en el instante: %s\n\n", nombre, Instant.now());
            }
        }
    }    
}
