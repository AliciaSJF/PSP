package Baul;

import java.time.Instant;

public class Consumidor implements Runnable {
    private int sacadas;
    private char caracter;
    private Baul baul;
    private String nombre;

    public Consumidor(char caracter, Baul baul, String nombre) {
        sacadas = 0;
        this.caracter = caracter;
        this.baul = baul;
        this.nombre = nombre;
    }

    public int getSacadas() {
        return sacadas;
    }

    public String getNombre() {
        return nombre;
    }

    public char getCaracter() {
        return caracter;
    }

    @Override
    public void run() {
        while (sacadas < 3) {
            synchronized(baul) {
                while (baul.estaVacio() || baul.getCaracter() != caracter) {
                    try {
                        baul.wait();
                    } catch (InterruptedException e) {
                        e.printStackTrace();
                    }
                }
                System.out.printf("%s vacía el carácter %s del baúl en el instante: %s\n", nombre, baul.sacar(), Instant.now());
                System.out.println(baul);
                sacadas++;
                System.out.printf("%s ha sacado %d %s en total\n", nombre, sacadas, caracter);
                baul.notifyAll();
                System.out.printf("%s espera a que se llene el baúl en el instante: %s\n\n", nombre, Instant.now());
            }
        }
        System.out.printf("%s ya ha sacado %d %s. HILO TERMINADO\n\n", nombre, sacadas, caracter);
    }
    
}
