package Baul;

public class Baul {
    private Character caracter;

    public Baul() {
        caracter = null;
    }

    public Character getCaracter() {
        return caracter;
    }

    public void setCaracter(Character caracter) {
        this.caracter = caracter;

    }

    public boolean estaVacio() {
        return caracter == null;
    }

    public Character sacar() {
        Character car = caracter;
        caracter = null;
        return car;
    }

    @Override
    public String toString() {
        return estaVacio() ? "Baúl vacío" : String.format("Baúl: [%c]", caracter);
    }
}