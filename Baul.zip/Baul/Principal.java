package Baul;

import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.TimeUnit;

public class Principal {
    public static void main(String[] args) {
        ExecutorService executor = Executors.newFixedThreadPool(4);
        Baul baul = new Baul();
        
        //numCaracteres TIENE QUE SER MÚLTIPLO DE 3 JESÚS EN ESTE CASO PARTICULAR
        Productor p = new Productor(baul, "PRODUCTOR", 9);
        
        Consumidor c1 = new Consumidor('A', baul, "C1");
        Consumidor c2 = new Consumidor('B', baul, "C2");
        Consumidor c3 = new Consumidor('C', baul, "C3");   

        executor.execute(p);
        executor.execute(c1);
        executor.execute(c2);
        executor.execute(c3);
        System.out.println("Todos los hilos se han creado han creado");
        System.out.println("Todos los hilos han comenzado. TTL 2 segundos\n");
        try {
            executor.awaitTermination(2, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            e.printStackTrace();
        }
        executor.shutdownNow();
        mostrarResumen(p, c1, c2, c3, baul);
        System.out.println("Todos los hilos han terminado");
    }

    public static void mostrarResumen(Productor p, Consumidor c1, Consumidor c2, Consumidor c3, Baul baul) {
        System.out.printf("El productor %s ha llenado el baúl con %d letras\n", p.getNombre(), p.getLlenadas());
        System.out.printf("El consumidor %s ha sacado del baúl %d letras %c\n", c1.getNombre(), c1.getSacadas(), c1.getCaracter());
        System.out.printf("El consumidor %s ha sacado del baúl %d letras %c\n", c2.getNombre(), c2.getSacadas(), c2.getCaracter());
        System.out.printf("El consumidor %s ha sacado del baúl %d letras %c\n", c3.getNombre(), c3.getSacadas(), c3.getCaracter());
        System.out.printf("%s\n", baul);
    }
}
